<?php
return [
    'database' => [
        'mysql' => [
            'dbname' => 'test',
            'host' => 'localhost',
            'user' => 'root',
            'password'=> null,
        ]
    ],
    'output_path' => __DIR__ . '/orm/',
    'namespace' => 'Orm',
];